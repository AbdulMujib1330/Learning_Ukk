<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class code extends CI_Controller {
    
	public function home()
	{
		$this->load->view('home');
	}
	public function login()
	{
		$this->load->view('petugas/login');
	}
	public function insert()
	{
	$nama_petugas = $this->input->post('nama_petugas');
	$username = $this->input->post('username');	
	$telp = $this->input->post('telp');
	// $petugas = $this->input->post('petugas');

	$query = $this->db->insert('petugas',array('nama_petugas'=>$nama_petugas,'username'=>$username,'telp'=>$telp,'level'=>'admin'));
	
	if($query){
		redirect('login');
	}
	}
}
