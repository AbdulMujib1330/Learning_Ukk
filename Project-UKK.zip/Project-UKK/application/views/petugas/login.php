<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url('css/home.css')?>">
    <link rel="stylesheet" href="<?= base_url('css/petugas_login.css')?>">
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <title>login</title>
</head>
<body>
<!-- <ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#news">News</a></li>
  <li><a href="#contact">Contact</a></li>
  <li><a href="home">Logout</a></li>
</ul>  -->
<div class="card d-flex align-item-center justify-content-center flex" style="width:25rem;height:20rem;">
  <form action="<?php echo site_url('code/insert')?>" method="post">
    <h1 class="text-center">Login</h1>
    <div class="form-group">
      <input type="text"      class="form-control mt-2" name="nama_petugas" placeholder="Name">
    </div>
    <div class="form-group">
      <input type="text"      class="form-control mt-2" name="username" placeholder="Username">
    </div>
    <div class="form-group">
      <input type="number"  class="form-control mt-2" name="telp" placeholder="telp">
    </div>
    <!-- <div class="form-group">
      <input type="text"    class="form-control mt-2" name="admin" id="exampleInputPassword1" placeholder="">
    </div> -->
    <button type="submit"     class="btn btn-primary">Submit</button>
  </form>
</div>
</body>
</html>